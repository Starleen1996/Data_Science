# 2048-python-para-data-science-trabajar-con-funciones
Este repositorio corresponde al entrenamiento de Python: Trabajar con funciones, estructuras de datos y funciones de Alura Latam.
